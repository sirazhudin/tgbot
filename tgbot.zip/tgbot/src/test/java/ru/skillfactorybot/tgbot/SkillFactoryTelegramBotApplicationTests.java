package ru.skillfactorybot.tgbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillFactoryTelegramBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
